package net.faultlinesmp.ships;

import org.bukkit.Material;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * The five ships and their block layouts.
 *
 * Local coordinates: +x is the bow (front), -x the stern, +z starboard (right), y = 0 is the top water block
 * (the bottom of the hull sits in it). Block data facings are local too: "east" points at the bow, "south" to
 * starboard. Every cell is one block the players place while building.
 */
enum ShipType {
    SLOOP("Sloop", "small", 150, 0.36, 3.6, 0, false),
    BRIGANTINE("Brigantine", "medium", 350, 0.30, 2.4, 27, true),
    GALLEON("Galleon", "big", 700, 0.25, 1.6, 54, true),
    DINGHY("Dinghy", "tiny", 60, 0.42, 5.5, 9, false),        // a rowboat for fishing: no cannons, a little fish hold
    PIRATE("Pirate Ship", "pirate", 900, 0.27, 1.8, 54, true); // black sails, skull and crossbones

    /** What a cell needs: any block of a kind (any wood works, the ship keeps the one you used). */
    enum Need {
        PLANKS("Planks", Material.OAK_PLANKS), LOG("Logs", Material.OAK_LOG), FENCE("Wooden Fences", Material.OAK_FENCE),
        STAIRS("Wooden Stairs", Material.OAK_STAIRS), WOOL("Wool (sails)", Material.WHITE_WOOL),
        CHEST("Chests", Material.CHEST), LANTERN("Lanterns", Material.LANTERN), LADDER("Ladders", Material.LADDER),
        TRAPDOOR("Wooden Trapdoors", Material.SPRUCE_TRAPDOOR), PANE("Glass Panes", Material.GLASS_PANE),
        CANNON("Ship Cannons", Material.IRON_BLOCK), // a custom item, checked by the plugin
        HATCH("Wooden Trapdoors", Material.SPRUCE_TRAPDOOR), // the hatch down to the hold: it opens
        SAIL_BLACK("Black Wool", Material.BLACK_WOOL), SAIL_WHITE("White Wool", Material.WHITE_WOOL);

        final String label;
        final Material ghost;
        Need(String label, Material ghost) { this.label = label; this.ghost = ghost; }

        private static final String[] WOODS = {"OAK", "SPRUCE", "BIRCH", "JUNGLE", "ACACIA", "DARK_OAK", "MANGROVE",
                "CHERRY", "PALE_OAK", "BAMBOO", "CRIMSON", "WARPED"};

        /** By name, so it works on every version (and in tests, where block tags are empty). */
        boolean accepts(Material m) {
            if (m == null || !m.isBlock()) return false;
            String n = m.name();
            return switch (this) {
                case PLANKS -> n.endsWith("_PLANKS");
                case LOG -> !n.contains("POTTED") && (n.endsWith("_LOG") || n.endsWith("_WOOD") || n.endsWith("_HYPHAE")
                        || ((n.endsWith("_STEM")) && (n.contains("CRIMSON") || n.contains("WARPED"))) // not melon/pumpkin stems
                        || n.equals("BAMBOO_BLOCK") || n.equals("STRIPPED_BAMBOO_BLOCK"));
                case FENCE -> n.endsWith("_FENCE") && wood(n);
                case STAIRS -> n.endsWith("_STAIRS") && wood(n);
                case WOOL -> n.endsWith("_WOOL");
                case CHEST -> m == Material.CHEST || m == Material.TRAPPED_CHEST || m == Material.BARREL;
                case LANTERN -> m == Material.LANTERN || m == Material.SOUL_LANTERN;
                case LADDER -> m == Material.LADDER;
                case TRAPDOOR, HATCH -> n.endsWith("_TRAPDOOR") && wood(n);
                case SAIL_BLACK -> m == Material.BLACK_WOOL;
                case SAIL_WHITE -> m == Material.WHITE_WOOL;
                case PANE -> n.endsWith("GLASS_PANE");
                case CANNON -> false;
            };
        }

        /** Not a full block: while anchored the real block stands there (stairs you walk up, fences you can't hop, ladders). */
        boolean shaped() {
            return this == STAIRS || this == FENCE || this == TRAPDOOR || this == HATCH || this == PANE || this == LADDER || this == LANTERN;
        }

        boolean sail() { return this == WOOL || this == SAIL_BLACK || this == SAIL_WHITE; }

        private static boolean wood(String n) {
            for (String w : WOODS) if (n.startsWith(w + "_")) return true;
            return false;
        }
    }

    /** One block of the ship. props = block state in local facings, e.g. "facing=west,half=bottom". */
    record Cell(int x, int y, int z, Need need, String props) {}

    final String title, size;
    final double maxHp, speed, turn; // speed in blocks/tick at full sail, turn in degrees/tick
    final int cargo;                 // cargo slots (0 = no hold)
    final boolean deep;              // needs water under the keel too
    List<Cell> cells;
    double[][] seats;                // local x, y (feet), z; seat 0 is the helm
    int deckY, minX, maxX, halfWidth, height;
    List<Integer> probes;            // cells checked against the world while sailing (hull sides, rails, keel)
    Map<Long, Integer> index;        // local x,y,z -> cell number
    Set<Integer> loose;              // ladders (and what holds them): never checked against the shore, so rivers stay passable
    int flagX, flagY;                // where a banner flies: on top of the tallest mast

    ShipType(String title, String size, double maxHp, double speed, double turn, int cargo, boolean deep) {
        this.title = title; this.size = size; this.maxHp = maxHp; this.speed = speed; this.turn = turn;
        this.cargo = cargo; this.deep = deep;
    }

    static {
        for (ShipType t : values()) t.build();
    }

    static long key3(int x, int y, int z) { return ((long) (x & 0x1fffff) << 42) | ((long) (y & 0x1fffff) << 21) | (z & 0x1fffff); }

    int cellAt(int x, int y, int z) {
        Integer i = index.get(key3(x, y, z));
        return i == null ? -1 : i;
    }

    static ShipType of(String s) {
        if (s == null) return null;
        for (ShipType t : values()) if (t.name().equalsIgnoreCase(s) || t.size.equalsIgnoreCase(s) || t.title.equalsIgnoreCase(s)) return t;
        return null;
    }

    Map<Need, Integer> bill() {
        Map<Need, Integer> m = new LinkedHashMap<>();
        for (Need n : Need.values()) m.put(n, 0);
        for (Cell c : cells) m.merge(c.need(), 1, Integer::sum);
        m.values().removeIf(v -> v == 0);
        return m;
    }

    // =====================================================================================================
    //  layouts
    // =====================================================================================================
    private void build() {
        Layout l = new Layout();
        switch (this) {
            case SLOOP -> {
                l.hull(-4, new int[]{3, 5, 5, 5, 5, 5, 5, 3, 1}, 1, 1);
                l.mast(0, 2, 9);
                l.sail(0, 3, new int[]{2, 2, 2, 1, 1});
                l.bowsprit(5, 2, 2);
                l.helm(-2, 2);
                l.lantern(-4, 3, -1); l.lantern(-4, 3, 1);
                l.ladder(-1);
                l.cannon(2);
                l.seat(1, 2, -1); l.seat(1, 2, 1);
            }
            case BRIGANTINE -> {
                l.hull(-7, new int[]{5, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 5, 3, 1}, 1, 2);
                l.castle(-7, -4, 2, -1, 1, true);
                l.mast(-1, 2, 12);
                l.sail(-1, 4, new int[]{3, 3, 3, 2, 2, 2});
                l.mast(4, 2, 10);
                l.sail(4, 4, new int[]{3, 3, 2, 2});
                l.bowsprit(8, 2, 3);
                l.helm(-5, 3);  // on the castle, clear of the stairs
                l.chest(2, 2, -2, "south");
                l.lantern(-7, 4, -2); l.lantern(-7, 4, 2);
                l.nest(-1, 11);
                l.ladder(-2);
                l.cannon(0); l.cannon(2);
                l.seat(1, 2, -2); l.seat(1, 2, 2); l.seat(-3, 2, -2); l.seat(-3, 2, 2);
            }
            case GALLEON -> {
                int[] w = new int[23];
                for (int i = 0; i < 23; i++) w[i] = 9;
                w[0] = 7; w[19] = 7; w[20] = 5; w[21] = 3; w[22] = 1;
                l.hull(-11, w, 3, 2, true);         // deck at 3: a hold below you can walk in
                l.castle(-11, -6, 4, -1, 1, true);  // quarterdeck
                l.castle(-11, -8, 5, 0, 0, true);   // poop deck, on top of it
                l.castle(7, 11, 4, -1, 1, false);   // forecastle
                l.mast(-3, 4, 17);
                l.sail(-3, 7, new int[]{3, 3, 3, 2, 2, 2});
                l.mast(2, 4, 20);
                l.sail(2, 7, new int[]{4, 4, 4, 3, 3, 2, 2});
                l.mast(7, 5, 16);
                l.sail(7, 8, new int[]{3, 3, 3, 2, 2});
                l.bowsprit(12, 5, 4);
                l.helm(-9, 6);  // on the poop deck
                l.chest(-1, 4, -3, "south"); l.chest(-1, 4, 3, "north");
                l.lantern(-11, 7, -3); l.lantern(-11, 7, 3);
                l.nest(2, 16);
                l.ladder(2);
                l.cannon(-2); l.cannon(0); l.cannon(4); l.cannon(6);
                l.window(-11, 2, -1); l.window(-11, 2, 1);           // stern windows
                for (int x : new int[]{-9, -7}) { l.window(x, 2, -4); l.window(x, 2, 4); }
                l.hatch(5, 1);
                l.hangingLantern(-2, 0); l.hangingLantern(8, 0);
                l.seat(0, 4, -3); l.seat(0, 4, 3); l.seat(4, 4, -3); l.seat(4, 4, 3);
                l.seat(-4, 4, -3); l.seat(-4, 4, 3); l.seat(-7, 5, -3); l.seat(-7, 5, 3);
            }
            case DINGHY -> l.dinghy();
            case PIRATE -> {
                int[] w = new int[25];
                for (int i = 0; i < 25; i++) w[i] = 9;
                w[0] = 7; w[21] = 7; w[22] = 5; w[23] = 3; w[24] = 1;
                l.hull(-12, w, 3, 2, true);
                l.castle(-12, -7, 4, -1, 1, true);   // quarterdeck
                l.castle(-12, -9, 5, 0, 0, true);    // poop deck
                l.castle(8, 12, 4, -1, 1, false);    // forecastle
                l.mast(-4, 4, 16);
                l.sailPattern(-3, 8, new String[]{"BBBBBBB", "BBBBBBB", "BBBBBBB", "BBBBBBB", "BBBBBBB", "BBBBBBB"});
                l.mast(1, 4, 22);
                l.sailPattern(2, 9, new String[]{   // the Jolly Roger, top row first
                        "BBBBBBBBB",
                        "BBWWWWWBB",
                        "BWWWWWWWB",
                        "BWBBWBBWB",
                        "BWWWBWWWB",
                        "BBWWWWWBB",
                        "BBWBWBWBB",
                        "WBBBBBBBW",
                        "BWBBBBBWB"});
                l.mast(5, 4, 18);
                l.sailPattern(6, 9, new String[]{
                        "BBBBBBB",
                        "BBWWWBB",
                        "BWBWBWB",
                        "BWWBWWB",
                        "BBWWWBB",
                        "WBBBBBW",
                        "BWBBBWB"});
                l.nest(1, 19);
                l.bowsprit(13, 5, 4);
                l.helm(-10, 6);
                l.lantern(-12, 7, -3); l.lantern(-12, 7, 3);
                l.ladder(-1);
                for (int x : new int[]{-5, -2, 1, 4, 7}) l.cannon(x);
                l.window(-12, 2, -1); l.window(-12, 2, 1);
                for (int x : new int[]{-10, -8}) { l.window(x, 2, -4); l.window(x, 2, 4); }
                l.hatch(3, 1);
                l.hangingLantern(-6, 0); l.hangingLantern(0, 0); l.hangingLantern(6, 0);
                l.chest(6, 1, -2, "south"); l.chest(6, 1, 2, "north");   // the hold, below deck
                l.seat(0, 4, -3); l.seat(0, 4, 3); l.seat(4, 4, -3); l.seat(4, 4, 3);
                l.seat(-3, 4, -3); l.seat(-3, 4, 3); l.seat(-8, 5, -3); l.seat(-8, 5, 3);
            }
        }
        l.finish(this);
    }

    /** Builds a layout: hull, raised decks, masts, sails, then rails around every deck and fence connections. */
    private static final class Layout {
        final Map<Long, Cell> cells = new LinkedHashMap<>();
        final List<Set<Long>> floors = new ArrayList<>();
        final List<Integer> floorY = new ArrayList<>();
        final List<Set<Long>> openings = new ArrayList<>();
        final List<double[]> seats = new ArrayList<>();
        final List<Cell> late = new ArrayList<>(); // placed after the rails (bowsprit, lanterns)
        int deckY, minX, maxX, half;
        double[] helmSeat;
        final Map<Integer, Integer> halfAt = new HashMap<>();
        final Set<Long> loose = new HashSet<>();

        static long key(int x, int z) { return ((long) x << 32) ^ (z & 0xffffffffL); }
        static long key3(int x, int y, int z) { return ShipType.key3(x, y, z); }

        void put(int x, int y, int z, Need n, String props) { cells.put(key3(x, y, z), new Cell(x, y, z, n, props)); }
        boolean has(int x, int y, int z) { return cells.containsKey(key3(x, y, z)); }

        void hull(int stern, int[] widths, int deckY, int inset) { hull(stern, widths, deckY, inset, false); }

        /**
         * inset: how much narrower each side of the bottom is than the deck (a narrow bottom fits rivers).
         * interior: a hold below the deck you can walk in (a full floor, walls sloping out to the deck).
         */
        void hull(int stern, int[] widths, int deckY, int inset, boolean interior) {
            this.deckY = deckY;
            minX = stern; maxX = stern + widths.length - 1;
            Set<Long> deck = new HashSet<>();
            for (int i = 0; i < widths.length; i++) {
                int x = stern + i, h = (widths[i] - 1) / 2;
                half = Math.max(half, h);
                halfAt.put(x, h);
                for (int z = -h; z <= h; z++) deck.add(key(x, z));
            }
            if (interior) {
                // floor at 0 (h - inset wide), then each layer one wider until the deck; only a layer's rim is wall
                for (int y = 0; y < deckY; y++) {
                    Set<Long> f = new HashSet<>();
                    for (int i = 0; i < widths.length; i++) {
                        int x = stern + i, h = (widths[i] - 1) / 2, hy = y == 0 ? h - inset : h - (deckY - 1 - y);
                        for (int z = -hy; z <= hy; z++) if (hy >= 0) f.add(key(x, z));
                    }
                    for (long k : f) {
                        int x = (int) (k >> 32), z = (int) k;
                        if (y == 0 || edge(f, x, z)) put(x, y, z, Need.PLANKS, "");
                    }
                }
                for (long k : deck) put((int) (k >> 32), deckY, (int) k, Need.PLANKS, "");
                floors.add(deck); floorY.add(deckY); openings.add(new HashSet<>());
                return;
            }
            for (int i = 0; i < widths.length; i++) {
                int x = stern + i, h = (widths[i] - 1) / 2, hb = Math.max(0, h - inset);
                for (int z = -h; z <= h; z++) {
                    put(x, deckY, z, Need.PLANKS, "");
                    // the bottom is a narrower ring with a keel down the middle: the deck overhangs it like a real hull
                    if (Math.abs(z) <= hb && (Math.abs(z) == hb || z == 0 || i == 0 || i == widths.length - 1)) put(x, 0, z, Need.PLANKS, "");
                    // a tall hull (deck at y 2) gets walls between the bottom and the deck
                    for (int y = 1; y < deckY; y++) if (edge(deck, x, z)) put(x, y, z, Need.PLANKS, "");
                }
            }
            floors.add(deck); floorY.add(deckY); openings.add(new HashSet<>());
        }

        /** A raised deck from x0 to x1 (inclusive) whose floor is at y, with stairs up to it on its open side. */
        void castle(int x0, int x1, int y, int stairZ0, int stairZ1, boolean stern) {
            Set<Long> main = floors.get(0), f = new HashSet<>(), open = new HashSet<>();
            for (long k : main) {
                int x = (int) (k >> 32), z = (int) k;
                if (x >= x0 && x <= x1) { f.add(k); put(x, y, z, Need.PLANKS, ""); }
            }
            int sx = stern ? x1 + 1 : x0 - 1, edgeX = stern ? x1 : x0;
            for (int z = stairZ0; z <= stairZ1; z++) {
                put(sx, y, z, Need.STAIRS, "facing=" + (stern ? "west" : "east") + ",half=bottom,shape=straight");
                open.add(key(edgeX, z));
            }
            floors.add(f); floorY.add(y); openings.add(open);
        }

        void mast(int x, int y0, int y1) { for (int y = y0; y <= y1; y++) put(x, y, 0, Need.LOG, "axis=y"); }

        /** Square sail across the ship at the mast, rows from the bottom up (half widths); a yard on top. */
        void sail(int x, int y0, int[] halves) {
            for (int r = 0; r < halves.length; r++) for (int z = -halves[r]; z <= halves[r]; z++) {
                if (z != 0) put(x, y0 + r, z, Need.WOOL, "");
            }
            int top = halves[halves.length - 1];
            for (int z = -top; z <= top; z++) if (z != 0) put(x, y0 + halves.length, z, Need.FENCE, "");
        }

        /** A sail of black and white wool hung in front of the mast (so it's whole), top row first; a yard on top. */
        void sailPattern(int x, int yTop, String[] rows) {
            for (int r = 0; r < rows.length; r++) {
                String row = rows[r];
                int half = row.length() / 2, y = yTop + rows.length - 1 - r;
                for (int c = 0; c < row.length(); c++) put(x, y, c - half, row.charAt(c) == 'W' ? Need.SAIL_WHITE : Need.SAIL_BLACK, "");
            }
            int half = rows[0].length() / 2;
            for (int z = -half; z <= half; z++) put(x, yTop + rows.length, z, Need.FENCE, "");
        }

        /** A trapdoor in the deck at (x, z), and a ladder down to the hold's floor on a post. */
        void hatch(int x, int z) {
            put(x, deckY, z, Need.HATCH, "facing=east,half=top,open=false");
            for (int y = 1; y < deckY; y++) {
                put(x, y, z, Need.LADDER, "facing=east");
                put(x - 1, y, z, Need.PLANKS, "");
            }
        }

        void hangingLantern(int x, int z) { put(x, deckY - 1, z, Need.LANTERN, "hanging=true"); }

        /** The rowboat: a flat bottom, a rim, two oars and a lantern on the stern. */
        void dinghy() {
            deckY = 0; minX = -2; maxX = 2; half = 1;
            for (int x = -2; x <= 2; x++) {
                int h = x == 2 ? 0 : 1;
                halfAt.put(x, h);
                for (int z = -h; z <= h; z++) put(x, 0, z, Need.PLANKS, "");
            }
            for (int x = -2; x <= 1; x++) { put(x, 1, -1, Need.PLANKS, ""); put(x, 1, 1, Need.PLANKS, ""); }
            put(-2, 1, 0, Need.PLANKS, ""); put(2, 1, 0, Need.PLANKS, "");
            put(0, 1, -2, Need.FENCE, ""); put(0, 1, 2, Need.FENCE, "");   // the oars
            late.add(new Cell(-2, 2, 0, Need.LANTERN, "hanging=false"));
            helmSeat = new double[]{-1, 1, 0};
            seats.add(new double[]{1, 1, 0});
        }

        void bowsprit(int x0, int y, int len) { for (int i = 0; i < len; i++) late.add(new Cell(x0 + i, y, 0, Need.FENCE, "")); }
        void lantern(int x, int y, int z) { late.add(new Cell(x, y, z, Need.LANTERN, "hanging=false")); }
        void chest(int x, int y, int z, String facing) { put(x, y, z, Need.CHEST, "facing=" + facing); }
        void seat(int x, int y, int z) { seats.add(new double[]{x, y, z}); }

        /** A ladder down each side to the water, a gap in the rail at the top. */
        void ladder(int x) {
            int h = halfAt.get(x);
            for (int s : new int[]{-1, 1}) {
                for (int y = 0; y <= deckY; y++) {
                    put(x, y, s * (h + 1), Need.LADDER, "facing=" + (s > 0 ? "south" : "north"));
                    loose.add(key3(x, y, s * (h + 1)));
                }
                if (!has(x, 0, s * h)) { put(x, 0, s * h, Need.PLANKS, ""); loose.add(key3(x, 0, s * h)); } // what the bottom rung hangs on
                openings.get(0).add(key(x, s * h));
            }
        }

        /** A cannon on each side, standing in the rail and pointing out. */
        void cannon(int x) {
            int h = halfAt.get(x);
            for (int s : new int[]{-1, 1}) put(x, deckY + 1, s * h, Need.CANNON, "facing=" + (s > 0 ? "south" : "north"));
        }

        /** A crow's nest: a trapdoor platform round the mast at y with a fence ring on it. */
        void nest(int mx, int y) {
            for (int dx = -1; dx <= 1; dx++) for (int dz = -1; dz <= 1; dz++) {
                if (dx == 0 && dz == 0) continue;
                put(mx + dx, y, dz, Need.TRAPDOOR, "facing=north,half=top,open=false");
                late.add(new Cell(mx + dx, y + 1, dz, Need.FENCE, ""));
            }
        }

        void window(int x, int y, int z) { put(x, y, z, Need.PANE, ""); }

        /** The wheel: a fence post on the deck at floor level y, the captain sits right behind it. */
        void helm(int x, int y) { put(x, y, 0, Need.FENCE, ""); helmSeat = new double[]{x - 1, y, 0}; }

        static boolean edge(Set<Long> f, int x, int z) {
            return !f.contains(key(x + 1, z)) || !f.contains(key(x - 1, z)) || !f.contains(key(x, z + 1)) || !f.contains(key(x, z - 1));
        }

        void finish(ShipType t) {
            // rails around every deck (skip where something already stands, or where stairs come up)
            for (int i = 0; i < floors.size(); i++) {
                Set<Long> f = floors.get(i);
                int y = floorY.get(i) + 1;
                for (long k : f) {
                    int x = (int) (k >> 32), z = (int) k;
                    if (!edge(f, x, z) || openings.get(i).contains(k) || has(x, y, z)) continue;
                    // a raised deck's edge over open main deck needs a rail; its outer edge too
                    put(x, y, z, Need.FENCE, "");
                }
            }
            for (Cell c : late) put(c.x(), c.y(), c.z(), c.need(), c.props());
            // fences connect to fences and solid blocks beside them
            List<Cell> out = new ArrayList<>();
            for (Cell c : cells.values()) {
                if (c.need() != Need.FENCE && c.need() != Need.PANE) { out.add(c); continue; }
                String p = "east=" + joins(c.x() + 1, c.y(), c.z()) + ",west=" + joins(c.x() - 1, c.y(), c.z())
                        + ",south=" + joins(c.x(), c.y(), c.z() + 1) + ",north=" + joins(c.x(), c.y(), c.z() - 1);
                out.add(new Cell(c.x(), c.y(), c.z(), c.need(), p));
            }
            // build order: bottom up, so the ghost fills in like a real build
            out.sort((a, b) -> a.y() != b.y() ? Integer.compare(a.y(), b.y()) : a.x() != b.x() ? Integer.compare(a.x(), b.x()) : Integer.compare(a.z(), b.z()));
            t.cells = Collections.unmodifiableList(out);
            List<double[]> s = new ArrayList<>();
            s.add(helmSeat);
            s.addAll(seats);
            t.seats = s.toArray(new double[0][]);
            t.deckY = deckY; t.minX = minX; t.maxX = maxX; t.halfWidth = half;
            int top = 0;
            for (Cell c : out) top = Math.max(top, c.y());
            t.height = top + 1;
            // probes: the bottom, and the outer cells of everything up to the rails (what would scrape the shore)
            Map<Long, Integer> idx = new HashMap<>();
            for (int i = 0; i < out.size(); i++) idx.put(key3(out.get(i).x(), out.get(i).y(), out.get(i).z()), i);
            List<Integer> probes = new ArrayList<>();
            for (int i = 0; i < out.size(); i++) {
                Cell c = out.get(i);
                boolean outer = !idx.containsKey(key3(c.x() + 1, c.y(), c.z())) || !idx.containsKey(key3(c.x() - 1, c.y(), c.z()))
                        || !idx.containsKey(key3(c.x(), c.y(), c.z() + 1)) || !idx.containsKey(key3(c.x(), c.y(), c.z() - 1));
                if (c.y() == 0 || (outer && c.y() <= deckY + 2) || c.x() > maxX) probes.add(i);
            }
            Set<Integer> lo = new HashSet<>();
            for (long k : loose) { Integer i = idx.get(k); if (i != null) lo.add(i); }
            probes.removeIf(lo::contains);
            t.probes = Collections.unmodifiableList(probes);
            t.index = Collections.unmodifiableMap(idx);
            t.loose = Collections.unmodifiableSet(lo);
            int fx = 0, fy = -1;
            for (Cell c : out) if (c.need() == Need.LOG && c.z() == 0 && c.y() > fy) { fy = c.y(); fx = c.x(); }
            t.flagX = fx; t.flagY = fy + 1;
        }

        boolean joins(int x, int y, int z) {
            Cell n = cells.get(key3(x, y, z));
            return n != null && (n.need() == Need.FENCE || n.need() == Need.PLANKS || n.need() == Need.LOG || n.need() == Need.STAIRS
                    || n.need() == Need.PANE || n.need().sail());
        }
    }
}

#!/usr/bin/env python3
"""Whole-boss previews of the wild models, posed with the same math as FaultlineBosses' Wild.Part.pose:

    world = pos + Ry(-yaw) * Rx(pitch) * Rz(roll) * Q0 * local * (k * p)        (Q0 = Ry(-90 deg): local +x -> south)

so a part placed the way the plugin places it shows here where it shows in game. Each scene below mirrors a boss's
place()/bodyTick() code. Faces are flat-shaded with their texture's average colour, painter's-sorted.

Usage: python3 tools/wild_rig_preview.py <out-dir>       (writes rig_<boss>.png, several poses side by side)
"""
import math
import os
import sys

import numpy as np
from PIL import Image, ImageDraw

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import wild_assets as W  # noqa: E402


def Ry(a): c, s = math.cos(a), math.sin(a); return np.array([[c, 0, s], [0, 1, 0], [-s, 0, c]])
def Rx(a): c, s = math.cos(a), math.sin(a); return np.array([[1, 0, 0], [0, c, -s], [0, s, c]])
def Rz(a): c, s = math.cos(a), math.sin(a); return np.array([[c, -s, 0], [s, c, 0], [0, 0, 1]])


Q0 = Ry(math.radians(-90))
I3 = np.eye(3)


def dir_of(yaw):
    r = math.radians(yaw)
    return np.array([-math.sin(r), 0.0, math.cos(r)])


def offset(base, yaw, f, u, r):
    fw = dir_of(yaw)
    right = np.array([-fw[2], 0, fw[0]])
    return np.asarray(base, float) + fw * f + np.array([0, u, 0]) + right * r


def yaw_of(v):
    return math.degrees(math.atan2(-v[0], v[2]))


def pitch_of(v):
    h = math.hypot(v[0], v[2])
    return math.degrees(-math.atan2(v[1], h))


class Built:
    def __init__(self):
        self.parts = {}
        for p in W.ALL_PARTS:
            img, boxes = W.build(p, hash(p.name) & 0xffff)
            tex = np.array(img).astype(float)
            faces = []
            for (a, b), regs in boxes:
                cols = {}
                for key, (x, y, w, h) in regs.items():
                    t = tex[y:y + h, x:x + w].reshape(-1, 4)
                    t = t[t[:, 3] > 0]
                    cols[key] = t[:, :3].mean(0) if len(t) else None
                faces.append((np.array(a), np.array(b), cols))
            self.parts[p.name] = faces


CORNERS = {"+x": [(1, 0, 0), (1, 1, 0), (1, 1, 1), (1, 0, 1)], "-x": [(0, 0, 0), (0, 0, 1), (0, 1, 1), (0, 1, 0)],
           "+y": [(0, 1, 0), (0, 1, 1), (1, 1, 1), (1, 1, 0)], "-y": [(0, 0, 0), (1, 0, 0), (1, 0, 1), (0, 0, 1)],
           "+z": [(0, 0, 1), (1, 0, 1), (1, 1, 1), (0, 1, 1)], "-z": [(0, 0, 0), (0, 1, 0), (1, 1, 0), (1, 0, 0)]}
NORMALS = {"+x": (1, 0, 0), "-x": (-1, 0, 0), "+y": (0, 1, 0), "-y": (0, -1, 0), "+z": (0, 0, 1), "-z": (0, 0, -1)}


class Scene:
    def __init__(self, built):
        self.b = built
        self.polys = []   # (world corners (4,3), colour, normal)

    def pose(self, name, k, pos, yaw, pitch=0.0, roll=0.0, local=None):
        D = Ry(math.radians(-yaw)) @ Rx(math.radians(pitch)) @ Rz(math.radians(roll)) @ Q0 @ (local if local is not None else I3)
        pos = np.asarray(pos, float)
        for a, b, cols in self.b.parts[name]:
            for key, cs in CORNERS.items():
                c = cols.get(key)
                if c is None: continue
                pts = np.array([[a[i] + (b[i] - a[i]) * cc[i] for i in range(3)] for cc in cs]) * k
                w = (D @ pts.T).T + pos
                n = D @ np.array(NORMALS[key], float)
                self.polys.append((w, c, n))

    def render(self, az=35, el=25, size=520, title=None, centre=None, span=None):
        if not self.polys: return Image.new("RGB", (size, size), (40, 44, 54))
        allp = np.concatenate([p[0] for p in self.polys])
        cen = np.asarray(centre, float) if centre is not None else (allp.min(0) + allp.max(0)) / 2
        R = Rx(math.radians(el)) @ Ry(math.radians(az))
        proj = [((R @ (p[0] - cen).T).T, p[1], R @ p[2]) for p in self.polys]
        ext = span or max(1e-3, max(np.abs(q[0][:, :2]).max() for q in proj)) * 2.1
        S = size / ext
        light = np.array([0.4, 0.8, 0.45]); light /= np.linalg.norm(light)
        img = Image.new("RGB", (size * 2, size * 2), (40, 44, 54))
        dr = ImageDraw.Draw(img)
        proj.sort(key=lambda q: q[0][:, 2].mean())  # far (smaller z after R? camera looks down -z) first
        for pts, col, n in proj:
            if n[2] < -1e-6: continue  # facing away
            shade = 0.55 + 0.45 * max(0.0, float(np.dot(Rx(math.radians(el)) @ Ry(math.radians(az)) @ light, n)))
            c = tuple(int(min(255, v * shade)) for v in col)
            xy = [((x * S + size) , (-y * S + size)) for x, y, _ in pts]
            dr.polygon(xy, fill=c)
        img = img.resize((size, size), Image.LANCZOS)
        if title:
            ImageDraw.Draw(img).text((8, 6), title, fill=(230, 230, 230))
        return img


def sheet(images, out):
    w = sum(i.width for i in images); h = max(i.height for i in images)
    s = Image.new("RGB", (w, h), (30, 32, 40))
    x = 0
    for i in images: s.paste(i, (x, 0)); x += i.width
    s.save(out)


# ---------------------------------------------------------------------------------------------------- scenes

def wyrm(built, flap_deg, landed=False, breath=False):
    """Mirrors FrostWyrm.place()."""
    sc = Scene(built)
    k, yaw, pitch = 1.4, 0.0, 0.0
    pos = np.array([0.0, 0.0, 0.0])
    sc.pose("wyrm_body", k, pos, yaw, pitch)
    base = offset(pos, yaw, 1.75 * k, 0.35 * k, 0)
    fwd, up = (2.9, 0.1) if breath else (2.5, 1.9) if landed else (2.4, 1.3)
    head = offset(pos, yaw, (1.75 + fwd) * k, (0.35 + up) * k, 0)
    ctrl = offset(pos, yaw, (1.75 + fwd * 0.45) * k, (0.35 + up * 0.95) * k, 0)
    pts = []
    for i in range(3):
        t = (i + 0.5) / 3
        p = (1 - t) ** 2 * base + 2 * (1 - t) * t * ctrl + t * t * head
        d = 2 * (1 - t) * (ctrl - base) + 2 * t * (head - ctrl)
        sc.pose("wyrm_neck", k * (1 - 0.06 * i), p, yaw_of(d), pitch_of(d))
    hp = 25 if breath else (-30 if landed else 8)
    sc.pose("wyrm_head", k, head, yaw, hp)
    jaw_parts(sc, "wyrm_head", k, head, yaw, hp, 40 if breath else 48 if landed else 6)
    fl = flap_deg
    shL, shR = offset(pos, yaw, 0.35 * k, 0.65 * k, -0.95 * k), offset(pos, yaw, 0.35 * k, 0.65 * k, 0.95 * k)
    sc.pose("wyrm_wing_l", k * 1.2, shL, yaw, pitch, 0, Rx(math.radians(fl)))
    sc.pose("wyrm_wing_r", k * 1.2, shR, yaw, pitch, 0, Rx(math.radians(-fl)))
    p = offset(pos, yaw, -2.2 * k, 0, 0)
    for i in range(6):
        name = "wyrm_tail_tip" if i == 5 else "wyrm_tail"
        kk = k * (1.0 - 0.1 * i)
        sway = math.sin(i * 0.8) * 0.4
        nxt = p + np.array([0, -0.12 * k if landed else 0.0, -1.0 * kk])
        d = p - nxt + np.array([sway, 0, 0])
        sc.pose(name, kk, p, yaw_of(d), pitch_of(d))
        p = p + np.array([sway * 0.5, -0.12 * k if landed else 0.0, -1.05 * kk])
    return sc


def frame(yaw, pitch, roll=0.0):
    return Ry(math.radians(-yaw)) @ Rx(math.radians(pitch)) @ Rz(math.radians(roll)) @ Q0


def jaw_parts(sc, head, k, pos, yaw, pitch, opened):
    """Mirrors the plugin: the Leviathan's / Frost Wyrm's jaw on its hinge, the Sandworm's four petals on the rim."""
    F = frame(yaw, pitch)
    if head == "lev_head":
        sc.pose("lev_jaw", k, np.asarray(pos) + F @ (np.array([0.5, -0.55, 0]) * k), yaw, pitch, 0, Rz(math.radians(-opened)))
    elif head == "wyrm_head":
        sc.pose("wyrm_jaw", k, np.asarray(pos) + F @ (np.array([0.4, -0.5, 0]) * k), yaw, pitch, 0, Rz(math.radians(-opened)))
    elif head == "worm_head":
        for i in range(4):
            T = Rx(math.radians(90 * i))
            sc.pose("worm_petal", k, np.asarray(pos) + F @ T @ (np.array([1.0, 1.0, 0]) * k), yaw, pitch, 0, T @ Rz(math.radians(opened)))


def serpent(built, head, body, tail, k, gap, segs, rise, tailk, opened=10, bedrock=False):
    """A chain body (Leviathan / Sandworm): the head rears up, the body trails back in a gentle S."""
    sc = Scene(built)
    pts = [np.array([0.0, rise * k, 0.0])]
    for i in range(1, segs + 2):
        ang = math.sin(i * 0.55) * 0.5
        y = max(0.0, rise * k - i * gap * 0.55)
        prev = pts[-1]
        step = np.array([math.sin(ang) * gap, 0, -math.cos(ang) * gap])
        nxt = prev + step
        nxt[1] = y
        pts.append(nxt)
    d0 = pts[0] - pts[1]
    if bedrock: sc.pose(head + "_b", k, pts[0], yaw_of(d0), 0)   # Bedrock: only yaw, the jaw/petals are bones in the pack
    else:
        sc.pose(head, k, pts[0], yaw_of(d0), pitch_of(d0) - 10)
        jaw_parts(sc, head, k, pts[0], yaw_of(d0), pitch_of(d0) - 10, opened)
    for i in range(1, segs + 1):
        d = pts[i - 1] - pts[i]
        sc.pose(body, k * (1 - 0.03 * i), pts[i], yaw_of(d), pitch_of(d))
    d = pts[segs] - pts[segs + 1]
    sc.pose(tail, k * tailk, pts[segs + 1], yaw_of(d), pitch_of(d))
    return sc


LICH_SH_L, LICH_SH_R, LICH_NECK, LICH_CAPE = (0.0, 0.8, -0.5), (0.0, 0.8, 0.5), (0.02, 0.86, 0), (-0.3, 0.9, 0)


def lich(built, lift=0.0, lean=0.0, roll=0.0, hy=0.0, hp=0.0, lsw=14, lsp=12, rsw=24, rsp=8, staff=3, cape=10, staff_fall=None):
    """Mirrors Lich.draw(): body at the waist, head on the neck, arms on the shoulders, the staff in the right hand."""
    sc = Scene(built)
    k, yaw = 1.3, 0.0
    waist = np.array([0, 2.02 * k + lift, 0])
    D = Ry(math.radians(-yaw)) @ Rx(math.radians(lean)) @ Rz(math.radians(roll)) @ Q0
    def J(o, M, p): return np.asarray(o, float) + M @ (np.array(p, float) * k)
    sc.pose("lich_body", k, waist, yaw, lean, roll)
    sc.pose("lich_head", k, J(waist, D, LICH_NECK), yaw + hy, lean + hp, roll * 0.5)
    sc.pose("lich_cape", k, J(waist, D, LICH_CAPE), yaw, lean, roll, Rz(math.radians(-cape)))
    lq = Rz(math.radians(lsw)) @ Rx(math.radians(lsp))
    rq = Rz(math.radians(rsw)) @ Rx(math.radians(-rsp))
    shL, shR = J(waist, D, LICH_SH_L), J(waist, D, LICH_SH_R)
    sc.pose("lich_arm", k, shL, yaw, lean, roll, lq)
    sc.pose("lich_arm", k, shR, yaw, lean, roll, rq)
    hand = J(shR, D @ rq, (0, -1.12, 0))
    if staff_fall is None:
        sc.pose("lich_staff", k, hand, yaw, lean, roll, Rz(math.radians(staff)))
    else:
        foot = np.array([hand[0], 0.0, hand[2]])
        M = Ry(math.radians(-(yaw + 40))) @ Q0 @ Rz(math.radians(staff_fall))
        sc.pose("lich_staff", k, J(foot, M, (0, 1.75, 0)), yaw + 40, 0, 0, Rz(math.radians(staff_fall)))
    return sc


def golem(built, aL, aR, sL, sR, lL, lR, bp, drop, hy=0.0, hp=0.0):
    """Mirrors StoneGolem.place()."""
    sc = Scene(built)
    k, yaw = 1.0, 0.0
    hip = np.array([0, (2.3 - drop) * k, 0])
    p = math.radians(bp)
    sc.pose("golem_body", k, hip, yaw, bp)
    sc.pose("golem_leg", k, offset(hip, yaw, 0, 0, -0.65 * k), yaw, 0, 0, Rz(math.radians(lL)))
    sc.pose("golem_leg", k, offset(hip, yaw, 0, 0, 0.65 * k), yaw, 0, 0, Rz(math.radians(lR)))
    sh, top = 2.45 * k, 2.82 * k
    sc.pose("golem_arm", k, offset(hip, yaw, math.sin(p) * sh, math.cos(p) * sh, -2.15 * k), yaw, bp, 0, Rz(math.radians(aL)) @ Rx(math.radians(sL)))
    sc.pose("golem_arm", k, offset(hip, yaw, math.sin(p) * sh, math.cos(p) * sh, 2.15 * k), yaw, bp, 0, Rz(math.radians(aR)) @ Rx(math.radians(-sR)))
    sc.pose("golem_head", k, offset(hip, yaw, math.sin(p) * top, math.cos(p) * top, 0), yaw + hy, bp + hp)
    return sc



def coralia(built, bp=0.0, roll=0.0, tail=0.0, fluke=0.0, hair=20.0, hy=0.0, hp=0.0, swL=20, spL=12, swR=20, spR=12, tilt=0.0, wrath=False):
    """Mirrors DeepBosses.Coralia.pose(): tail + fluke from the waist, torso, head on the neck, hair off the back of the
    head, arms on the shoulders, the trident in the right hand."""
    sc = Scene(built)
    k, yaw = 2.2, 0.0
    sfx = "_wrath" if wrath else ""
    pos = np.array([0, 3.2 * k, 0.0])
    F = frame(yaw, bp, roll)
    def J(o, M, p): return np.asarray(o, float) + M @ (np.array(p, float) * k)
    T = Rz(math.radians(tail))
    sc.pose("coralia_tail" + sfx, k, pos, yaw, bp, roll, T)
    sc.pose("coralia_fluke" + sfx, k, J(pos, F @ T, (-1.75, -2.8, 0)), yaw, bp, roll, T @ Rz(math.radians(40 + fluke)))
    sc.pose("coralia_torso" + sfx, k, pos, yaw, bp, roll)
    neck = J(pos, F, (0, 1.25, 0))
    H = Ry(math.radians(-hy)) @ Rz(math.radians(-hp))
    sc.pose("coralia_head" + sfx, k, neck, yaw, bp, roll, H)
    sc.pose("coralia_hair" + sfx, k, J(neck, F @ H, (-0.22, 0.72, 0)), yaw, bp, roll, H @ Rz(math.radians(-hair)))
    qL = Rz(math.radians(swL)) @ Rx(math.radians(spL))
    qR = Rz(math.radians(swR)) @ Rx(math.radians(-spR))
    shL, shR = J(pos, F, (0, 1.0, -0.55)), J(pos, F, (0, 1.0, 0.55))
    sc.pose("coralia_arm" + sfx, k, shL, yaw, bp, roll, qL)
    sc.pose("coralia_arm" + sfx, k, shR, yaw, bp, roll, qR)
    sc.pose("coralia_trident" + sfx, k, J(shR, F @ qR, (0, -1.3, 0)), yaw, bp, roll, qR @ Rz(math.radians(tilt)))
    return sc


def titan(built, lean=0.0, hy=0.0, hp=0.0, jaw=6.0, lY=-32, lP=38, rY=32, rP=38):
    """Mirrors DeepBosses.Titan.pose(): torso from the waist, head/eyes/lures on the neck, jaw on its hinge, arms from
    the shoulders, claws at the elbows (22 degrees lower)."""
    sc = Scene(built)
    k, yaw = 3.6, 0.0
    waist = np.array([0, 0.0, 0])
    F = frame(yaw, lean)
    def J(o, M, p): return np.asarray(o, float) + M @ (np.array(p, float) * k)
    sc.pose("titan_body", k, waist, yaw, lean)
    neck = J(waist, F, (0.2, 2.45, 0))
    H = frame(yaw + hy, hp + lean)
    sc.pose("titan_head", k, neck, yaw + hy, hp + lean)
    sc.pose("titan_eyes", k, neck, yaw + hy, hp + lean)
    sc.pose("titan_jaw", k, J(neck, H, (0.15, -0.3, 0)), yaw + hy, hp + lean, 0, Rz(math.radians(-jaw)))
    for i, l in enumerate(((0.9, 0.95, 0.0), (0.45, 0.95, -0.45), (0.45, 0.95, 0.45))):
        sc.pose("titan_lure", k, J(neck, H, l), yaw + hy, hp + lean - 8 * math.sin(i * 2))
    for s, ay, ap in ((-1, lY, lP), (1, rY, rP)):
        sh = J(waist, F, (0.15, 2.05, s * 1.45))
        sc.pose("titan_arm", k, sh, yaw + ay, ap)
        el = sh + frame(yaw + ay, ap) @ np.array([2.1 * k, 0, 0])
        sc.pose("titan_claw", k, el, yaw + ay, ap - 22)
    return sc


SCENES = {
    "coralia": lambda b: [coralia(b).render(az=-60, el=10, title="Coralia (front)", span=14),
                          coralia(b).render(az=120, el=10, title="back", span=14),
                          coralia(b, bp=72, tail=-18, fluke=-25, hair=70, hp=-50, swL=-25, spL=8, swR=-25, spR=8).render(az=-90, el=15, title="swimming", span=14),
                          coralia(b, bp=88, roll=30, tail=-10, fluke=20, hair=85, hp=-70, swL=-35, spL=10, swR=165, spR=4, tilt=180).render(az=-60, el=15, title="tidal dash (lance)", span=14),
                          coralia(b, bp=-10, tail=15, fluke=30, hair=30, hp=15, swL=40, spL=60, swR=175, spR=6, tilt=180).render(az=-60, el=10, title="trident raised", span=14),
                          coralia(b, bp=5, tail=-25, fluke=-30, hair=40, swL=60, spL=95, swR=60, spR=95, tilt=0).render(az=-60, el=10, title="waltz / aria", span=14),
                          coralia(b, wrath=True, hair=35, swL=30, spL=40, swR=150, spR=10, tilt=180).render(az=-60, el=10, title="WRATH (phase 3)", span=14)],
    "leviathan": lambda b: [serpent(b, "lev_head", "lev_body", "lev_tail", 1.0, 2.2, 7, 2.5, 0.75).render(title="the Leviathan"),
                            serpent(b, "lev_head", "lev_body", "lev_tail", 1.0, 2.2, 7, 2.5, 0.75, opened=42).render(az=100, el=8, title="side, roaring"),
                            serpent(b, "lev_head", "lev_body", "lev_tail", 1.0, 2.2, 7, 2.5, 0.75, bedrock=True).render(title="Bedrock")],
    "sandworm": lambda b: [serpent(b, "worm_head", "worm_body", "worm_tail", 1.5, 2.4 * 1.5, 7, 4, 0.8).render(title="the Sandworm King"),
                           serpent(b, "worm_head", "worm_body", "worm_tail", 1.5, 2.4 * 1.5, 7, 4, 0.8).render(az=-80, el=5, title="maw shut (front)"),
                           serpent(b, "worm_head", "worm_body", "worm_tail", 1.5, 2.4 * 1.5, 7, 4, 0.8, opened=65).render(az=-80, el=5, title="maw open (front)"),
                           serpent(b, "worm_head", "worm_body", "worm_tail", 1.5, 2.4 * 1.5, 7, 4, 0.8, opened=65).render(az=40, el=15, title="erupting"),
                           serpent(b, "worm_head", "worm_body", "worm_tail", 1.5, 2.4 * 1.5, 7, 4, 0.8, bedrock=True).render(title="Bedrock")],
    "lich": lambda b: [lich(b).render(az=-60, el=12, title="the Lich (front)", span=3.6),
                       lich(b).render(az=150, el=12, title="back", span=3.6),
                       lich(b, lift=0.3, lean=8, lsw=98, lsp=4, hy=-10).render(az=-30, el=12, title="soul bolt: throw", span=3.6),
                       lich(b, lift=0.9, lean=-14, hp=-25, lsw=165, lsp=28, rsw=150, rsp=18, staff=-8).render(az=-60, el=12, title="raise: arms up", span=3.6),
                       lich(b, lean=26, lsw=-20, lsp=30, rsw=55, rsp=0, staff=105).render(az=-100, el=12, title="blink: the strike", span=3.6),
                       lich(b, lean=22, lift=-0.2, hp=30, lsw=40, lsp=18, staff=8).render(az=-60, el=12, title="grasp: reaching down", span=3.6),
                       lich(b, lift=0.7, lean=-6, lsw=25, lsp=78, rsw=22, rsp=62, staff=0).render(az=-60, el=12, title="death ring", span=3.6),
                       lich(b, lift=1.2, lean=60, hp=50, lsw=3, lsp=4, rsw=4, rsp=4, cape=4, staff_fall=84).render(az=-60, el=12, title="death", span=3.6)],
    "golem": lambda b: [golem(b, 3, -3, 6, 6, 0, 0, 0, 0).render(az=-50, el=12, title="idle", span=11),
                        golem(b, -20, 20, 6, 6, 24, -24, 5, 0.1).render(az=-50, el=12, title="walking", span=11),
                        golem(b, 168, 168, 16, 16, 0, 0, -11, 0.13).render(az=-50, el=12, title="pound: wind-up", span=11),
                        golem(b, -8, -8, 10, 10, 0, 0, 20, 0.45, hp=18).render(az=-50, el=12, title="pound: SLAM", span=11),
                        golem(b, 20, 175, 6, 12, 0, 0, -14, 0.05).render(az=-50, el=12, title="boulder: heave", span=11),
                        golem(b, 30, 30, 14, 14, 38, -28, 18, 0.75, hp=22).render(az=-50, el=12, title="overgrowth: kneel", span=11)],
    "titan": lambda b: [titan(b).render(az=-60, el=12, title="the Abyssal Titan (front)", span=26),
                        titan(b).render(az=150, el=12, title="back", span=26),
                        titan(b).render(az=-90, el=5, title="side", span=26),
                        titan(b, lean=10, hp=20, jaw=40, lY=-60, lP=-20, rY=60, rP=-20).render(az=-50, el=12, title="slam: wind-up, roaring", span=26),
                        titan(b, jaw=30, lY=-50, lP=70, rY=50, rP=70).render(az=-50, el=12, title="stunned", span=26),
                        titan(b, hp=-30, jaw=55).render(az=-70, el=-10, title="devour (from below)", span=26)],
    "frostwyrm": lambda b: [wyrm(b, 35).render(title="flight, wings up"), wyrm(b, -30).render(title="flight, wings down"),
                            wyrm(b, 0, breath=True).render(az=90, el=10, title="frost breath (side)"),
                            wyrm(b, 62, landed=True).render(az=-30, el=15, title="landed, roaring")],
}


def main():
    out = sys.argv[1] if len(sys.argv) > 1 else "tools/previews"
    os.makedirs(out, exist_ok=True)
    only = sys.argv[2:] or list(SCENES)
    built = Built()
    for name in only:
        sheet(SCENES[name](built), os.path.join(out, f"rig_{name}.png"))
        print("wrote", os.path.join(out, f"rig_{name}.png"))


if __name__ == "__main__":
    main()
